﻿using $safeprojectname$.Models;
using Swashbuckle.Examples;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers
{
    public class DemoController : ApiController
    {
        /// <summary>
        /// 數值相加 (a+b)
        /// </summary>
        /// <param name="question">輸入數值</param>
        /// <returns></returns>
        [SwaggerResponseExample(HttpStatusCode.OK, typeof(AnswerExample))]
        [SwaggerRequestExample(typeof(Question), typeof(QuestionExample))]
        public Answer Post([FromBody]Question question)
        {
            return new Answer { ans = question.a + question.b };
        }
    }
}
