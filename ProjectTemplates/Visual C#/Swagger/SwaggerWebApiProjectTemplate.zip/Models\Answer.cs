﻿using Swashbuckle.Examples;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    /// <summary>
    /// 輸出答案
    /// </summary>
    public class Answer
    {
        /// <summary>
        /// 解答
        /// </summary>
        public int ans { get; set; }
    }

    /// <summary>
    /// 輸出範例
    /// </summary>
    public class AnswerExample : IExamplesProvider
    {
        public object GetExamples()
        {
            return new Answer[]{ new Answer { ans = 3 }, new Answer { ans = 1 } };
        }
    }
}