﻿using Swashbuckle.Examples;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    /// <summary>
    /// 輸入數值
    /// </summary>
    public class Question
    {
        /// <summary>
        /// 數值 a
        /// </summary>
        public int a { get; set; }
        /// <summary>
        /// 數值 b
        /// </summary>
        public int b { get; set; }
    }

    /// <summary>
    /// 輸入範例
    /// </summary>
    public class QuestionExample : IExamplesProvider
    {
        public object GetExamples()
        {
            return new Question { a = 2, b = 1 };
        }
    }
}